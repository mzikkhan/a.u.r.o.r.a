utils::globalVariables(c(
  ".data", "score", "metric", "value",
  "temp_c", "precip_mm",
  "avg_temp", "max_temp", "tot_rain",
  "natural_disaster_score", "political_unrest_score",
  "interest_rate", "mortgage_rate", "unemployment", "cpi_inflation", "gdp", "public_debt",
  "Date", "Series", "Value"
))