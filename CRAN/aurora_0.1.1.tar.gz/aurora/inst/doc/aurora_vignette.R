## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE
)

## ----setup--------------------------------------------------------------------
library(aurora)


## ----example-data-------------------------------------------------------------
set.seed(1)

dates <- seq(as.Date("2025-01-01"), as.Date("2025-03-31"), by = "day")

rev_data <- data.frame(
  Date = dates,
  Revenue = 100 + seq_along(dates) + stats::rnorm(length(dates), 0, 5),
  avg_temp = stats::rnorm(length(dates), 10, 4),
  max_temp = stats::rnorm(length(dates), 15, 5),
  tot_rain = stats::runif(length(dates), 0, 10),
  interest_rate = 5 + stats::rnorm(length(dates), 0, 0.2)
)

head(rev_data)

## ----plot, fig.width=12, fig.height=8-----------------------------------------
plots <- c("avg_temp", "max_temp", "tot_rain", "interest_rate")

plotter(
  rev_data,
  cols = plots,
  date_col = "Date",
  revenue_col = "Revenue",
  ncol = 2,
  scale_method = "zscore"
)

## ----real-data, eval=FALSE----------------------------------------------------
# # Fetches data from Open-Meteo, FRED, and GDELT
# data <- get_macroeconomic_data(
#   start_date = "2025-01-01",
#   end_date   = "2025-12-01",
#   latitude   = 55.6761,
#   longitude  = 12.5683
# )
# head(data)
# 
# # Merge with your revenue CSV (you must have this file locally)
# rev_data <- revenue_merge(data, "revenue_data_2025.csv")
# head(rev_data)
# 
# plots <- c("avg_temp", "max_temp", "tot_rain", "interest_rate")
# 
# plotter(
#   rev_data,
#   cols = plots,
#   date_col = "Date",
#   revenue_col = "Revenue",
#   ncol = 2,
#   scale_method = "zscore"
# )

